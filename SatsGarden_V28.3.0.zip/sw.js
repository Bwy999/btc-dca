"use strict";

const SW_BUILD = "28.3.0-20261128";
const CACHE_NAME = "btc-intelligence-v" + SW_BUILD.replace(/\./g, "-");
const CACHE_PREFIX = "btc-site:" + self.registration.scope + ":";
const SCOPED_CACHE = CACHE_PREFIX + CACHE_NAME;
// 带内容哈希的静态资源。文件内容不变，文件名就不变，更新时无需重新下载。
const ASSETS = /*ASSETS*/[
  "./assets/app.ffb6619994.css",
  "./assets/seed-cycle.5a6f45f52a.js",
  "./assets/app.09c1ed3b38.js",
  "./assets/insight.67c8b7276d.js",
]/*END*/;
// 按需下载的资源（英文对照表与 VHE 实验室）：不预缓存，但版本切换时不删除
const OPTIONAL_ASSETS = /*OPTIONAL*/["./assets/lightweight-charts.682f74d8c4.js", "./assets/i18n-en.ae8d607397.js", "./assets/ext-bundle.5b489ff1ee.js", "./assets/vhe.df65b8c01f.css", "./assets/vhe-engine.f3956e0e74.js", "./assets/vhe-ui.28164c1f7a.js", "./assets/vhe-worker.866c41fc23.js"]/*OEND*/;
const ASSET_CACHE = CACHE_PREFIX + "assets";
const CORE = [
  "./",
  "./index.html",
  "./ahr999.html",
  "./old-coins.html",
  "./dca.html",
  "./vhe.html",
  "./apple-touch-icon.png",
  "./btc-logo.png",
  "./manifest.webmanifest",
];

self.addEventListener("install", (event) => {
  event.waitUntil((async () => {
    const cache = await caches.open(SCOPED_CACHE);
    const page = await fetch(new Request("./index.html", {cache:"no-store"}));
    if (!page.ok || !(await page.clone().text()).includes('const BUILD_ID="' + SW_BUILD + '"')) {
      throw new Error("Page and worker builds differ; keep existing worker");
    }
    await cache.put("./index.html", page.clone());
    await cache.put("./", page);
    await Promise.allSettled(CORE.slice(2).map((url) => cache.add(new Request(url, { cache: "reload" }))));
    // 新版本用到的资源必须全部就绪，否则保留旧版本，避免页面引用缺失文件。
    const assetCache = await caches.open(ASSET_CACHE);
    const missing = [];
    for (const url of ASSETS) {
      if (!(await assetCache.match(url))) missing.push(url);
    }
    // 并发池预缓存（每次最多 6 个），兼顾弱网速度与完整性
    let idx = 0;
    const workers = Array.from({ length: Math.min(6, missing.length) }, async () => {
      while (idx < missing.length) {
        const url = missing[idx++];
        const res = await fetch(new Request(url, { cache: "reload" }));
        if (!res.ok) throw new Error("Asset missing: " + url);
        await assetCache.put(url, res);
      }
    });
    await Promise.all(workers);
    // An existing client keeps its worker until the user explicitly confirms.
  })());
});

self.addEventListener("activate", (event) => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    // Only clean our own scope. Legacy/ledger/other-site caches are not ours to delete.
    const obsolete = keys.filter((key) => key !== SCOPED_CACHE && key !== ASSET_CACHE && key.startsWith(CACHE_PREFIX));
    await Promise.allSettled(obsolete.map((key) => caches.delete(key)));
    // 资源缓存只删除当前版本不再使用的文件
    try {
      const assetCache = await caches.open(ASSET_CACHE);
      const keep = new Set(ASSETS.concat(OPTIONAL_ASSETS).map((u) => new URL(u, self.registration.scope).href));
      for (const req of await assetCache.keys()) if (!keep.has(req.url)) await assetCache.delete(req);
    } catch (_) {}
    await self.clients.claim();
  })());
});

self.addEventListener("message", (event) => {
  if (event.data?.type === "BTC_GET_VERSION") {
    event.ports?.[0]?.postMessage({build:SW_BUILD,cache:SCOPED_CACHE});
  }
  if (event.data?.type === "BTC_ACTIVATE_UPDATE" && event.data.build === SW_BUILD) {
    event.waitUntil(self.skipWaiting());
  }
});

async function networkFirst(request, fallbackUrl) {
  const cache = await caches.open(SCOPED_CACHE).catch(() => null);
  const ctrl = typeof AbortController !== "undefined" ? new AbortController() : null;
  const timer = ctrl ? setTimeout(() => { try { ctrl.abort(); } catch (_) {} }, 3500) : null;
  try {
    const response = await fetch(request, ctrl ? { signal: ctrl.signal } : undefined);
    if (timer) clearTimeout(timer);
    if (response?.type === "opaqueredirect") return response;
    if (!response?.ok) {
      if (response?.status === 404 && !fallbackUrl) return response;
      throw new Error(`HTTP ${response?.status || 0}`);
    }
    if(cache)try { await cache.put(request, response.clone()); } catch (_) {}
    return response;
  } catch {
    if (timer) clearTimeout(timer);
    return (cache ? await cache.match(request).catch(() => null) : null)
      || (cache && fallbackUrl ? await cache.match(fallbackUrl).catch(() => null) : null)
      || Response.error();
  }
}

async function staleWhileRevalidate(request, event) {
  const cache = await caches.open(SCOPED_CACHE).catch(() => null);
  const cached = cache ? await cache.match(request).catch(() => null) : null;
  const update = fetch(request).then(async (response) => {
    if (response?.ok && cache) try { await cache.put(request, response.clone()); } catch (_) {}
    return response;
  }).catch(() => null);
  event.waitUntil(update);
  if (cached) return cached;
  return await update || Response.error();
}

self.addEventListener("fetch", (event) => {
  const request = event.request;
  if (request.method !== "GET") return;

  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;

  if (url.searchParams.has("_btc_update") || url.pathname.endsWith("/sw.js")) {
    event.respondWith(fetch(new Request(request, {cache:"no-store"})));
    return;
  }

  // 预先计算的数据（data/*.json）：优先取网络上的最新版本；只有合法 JSON（v === 1）才写入缓存，
  // 若服务器对缺失文件返回 SPA 网页（text/html），无缓存时直接转为 404 JSON，避免页面重复解析整份网页。
  if (url.pathname.includes("/data/")) {
    event.respondWith((async () => {
      const key = new Request(url.origin + url.pathname);
      const c = await caches.open(SCOPED_CACHE).catch(() => null);
      const cached = async () => (c ? await c.match(key).catch(() => null) : null);
      try {
        const res = await fetch(new Request(request, {cache:"no-store"}));
        if (res.ok) {
          const ct = (res.headers.get("content-type") || "").toLowerCase();
          if (ct.includes("text/html")) {
            const hit = await cached();
            return hit || new Response("{}", {status: 404, headers: {"content-type": "application/json"}});
          }
          let valid = false;
          try { const j = JSON.parse(await res.clone().text()); valid = !!j && typeof j === "object" && j.v === 1; } catch (_) {}
          if (valid) { if (c) try { await c.put(key, res.clone()); } catch (_) {} return res; }
        }
        const hit = await cached();
        return hit || res;
      } catch (_) {
        const hit = await cached();
        return hit || Response.error();
      }
    })());
    return;
  }

  if (url.pathname.includes("/assets/")) {
    event.respondWith((async () => {
      const assetCache = await caches.open(ASSET_CACHE).catch(() => null);
      const hit = assetCache ? await assetCache.match(request).catch(() => null) : null;
      if (hit) return hit;
      const res = await fetch(request);
      if (res.ok && assetCache) try { await assetCache.put(request, res.clone()); } catch (_) {}
      return res;
    })());
    return;
  }

  if (request.mode === "navigate") {
    const p = url.pathname;
    const fallback = p.endsWith("/ahr999.html")
        ? "./ahr999.html"
        : p.endsWith("/old-coins.html")
          ? "./old-coins.html"
          : p.endsWith("/dca.html")
            ? "./dca.html"
            : p.endsWith("/vhe.html")
              ? "./vhe.html"
              : (p.endsWith("/") || p.endsWith("/index.html"))
                ? "./index.html"
                : null;
    event.respondWith(networkFirst(request, fallback));
    return;
  }

  event.respondWith(staleWhileRevalidate(request, event));
});
